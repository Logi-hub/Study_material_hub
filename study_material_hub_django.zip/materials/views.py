from rest_framework import generics, filters, status
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.decorators import api_view
from django.http import FileResponse
from .models import StudyMaterial
from .serializers import StudyMaterialSerializer

class StudyMaterialListView(generics.ListAPIView):
    queryset = StudyMaterial.objects.all()
    serializer_class = StudyMaterialSerializer
    filter_backends = [filters.SearchFilter, DjangoFilterBackend]
    search_fields = ['title', 'subject', 'year']
    filterset_fields = ['branch', 'year']

@api_view(['GET'])
def download_material(request, pk):
    try:
        material = StudyMaterial.objects.get(pk=pk)
        return FileResponse(material.file.open(), as_attachment=True)
    except StudyMaterial.DoesNotExist:
        return Response({"error": "File not found"}, status=status.HTTP_404_NOT_FOUND)

@api_view(['POST'])
def mark_favourite(request, pk):
    try:
        material = StudyMaterial.objects.get(pk=pk)
        material.is_favourite = True
        material.save()
        return Response({'message': 'Marked as favourite'})
    except StudyMaterial.DoesNotExist:
        return Response({'error': 'Material not found'}, status=404)

@api_view(['POST'])
def rate_comment(request, pk):
    try:
        material = StudyMaterial.objects.get(pk=pk)
        material.rating = request.data.get('rating', material.rating)
        material.comment = request.data.get('comment', material.comment)
        material.save()
        return Response({'message': 'Updated rating/comment'})
    except StudyMaterial.DoesNotExist:
        return Response({'error': 'Material not found'}, status=404)
