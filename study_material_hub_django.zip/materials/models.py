from django.db import models

class StudyMaterial(models.Model):
    title = models.CharField(max_length=200)
    subject = models.CharField(max_length=100)
    branch = models.CharField(max_length=100)
    year = models.IntegerField()
    file = models.FileField(upload_to='materials/')
    is_favourite = models.BooleanField(default=False)
    rating = models.IntegerField(default=0)
    comment = models.TextField(blank=True)

    def __str__(self):
        return self.title
