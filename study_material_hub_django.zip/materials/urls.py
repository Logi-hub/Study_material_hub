from django.urls import path
from .views import (
    StudyMaterialListView,
    download_material,
    mark_favourite,
    rate_comment
)

urlpatterns = [
    path('materials/', StudyMaterialListView.as_view(), name='material-list'),
    path('materials/download/<int:pk>/', download_material, name='material-download'),
    path('materials/favourite/<int:pk>/', mark_favourite, name='material-favourite'),
    path('materials/rate_comment/<int:pk>/', rate_comment, name='rate-comment'),
]
